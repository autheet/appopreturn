"use client";

import { useState, useEffect, useRef, useTransition } from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { submitDigest } from "@/app/actions";
import {
  FileUp,
  Fingerprint,
  CheckCircle,
  Loader,
  Link as LinkIcon,
  Clock,
  RefreshCw,
} from "lucide-react";

type TransactionResult = {
  txId: string;
  timestamp: Date;
  network: "testnet" | "mainnet";
};

export function ApreturnClient() {
  const [file, setFile] = useState<File | null>(null);
  const [digest, setDigest] = useState<string | null>(null);
  const [isHashing, setIsHashing] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const [transactionResult, setTransactionResult] =
    useState<TransactionResult | null>(null);
  const [isPending, startTransition] = useTransition();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!file) return;

    const calculateHash = async () => {
      setIsHashing(true);
      try {
        const buffer = await file.arrayBuffer();
        const hashBuffer = await window.crypto.subtle.digest("SHA-256", buffer);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        const hashHex = hashArray
          .map((b) => b.toString(16).padStart(2, "0"))
          .join("");
        setDigest(hashHex);
      } catch (err) {
        console.error(err);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Could not calculate file hash.",
        });
        setFile(null);
      } finally {
        setIsHashing(false);
      }
    };

    calculateHash();
  }, [file, toast]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setDigest(null);
      setTransactionResult(null);
    }
  };

  const handleSubmit = () => {
    if (!digest) return;
    const network = isPremium ? "mainnet" : "testnet";

    startTransition(async () => {
      const result = await submitDigest(digest, network);
      if (result.error) {
        toast({
          variant: "destructive",
          title: "Submission Failed",
          description: result.error,
        });
      } else {
        setTransactionResult({
          txId: result.txId!,
          timestamp: new Date(result.timestamp!),
          network,
        });
        toast({
            title: "Success!",
            description: "Your file's digest has been recorded.",
        });
      }
    });
  };

  const reset = () => {
    setFile(null);
    setDigest(null);
    setTransactionResult(null);
    if (fileInputRef.current) {
        fileInputRef.current.value = "";
    }
  };

  const getExplorerLink = (txId: string, network: "testnet" | "mainnet") => {
    if (network === "testnet") {
      return `https://mempool.space/testnet/tx/${txId}`;
    }
    return `https://mempool.space/tx/${txId}`;
  };

  const renderContent = () => {
    if (transactionResult) {
      return (
        <div className="text-center">
          <CheckCircle className="mx-auto h-12 w-12 text-green-500" />
          <h3 className="mt-4 text-lg font-medium">Notarization Complete</h3>
          <div className="mt-4 space-y-3 text-left bg-muted p-4 rounded-lg">
             <div className="flex items-start">
                <LinkIcon className="h-5 w-5 mr-3 mt-1 text-muted-foreground" />
                <div>
                    <p className="font-semibold">Transaction ID</p>
                    <a href={getExplorerLink(transactionResult.txId, transactionResult.network)} target="_blank" rel="noopener noreferrer" className="text-sm text-primary break-all hover:underline">{transactionResult.txId}</a>
                </div>
             </div>
             <div className="flex items-start">
                <Clock className="h-5 w-5 mr-3 mt-1 text-muted-foreground" />
                <div>
                    <p className="font-semibold">Timestamp (UTC)</p>
                    <p className="text-sm text-muted-foreground">{transactionResult.timestamp.toLocaleString('en-US', { timeZone: 'UTC' })}</p>
                </div>
             </div>
          </div>
          <Button onClick={reset} className="mt-6 w-full">
            <RefreshCw className="mr-2 h-4 w-4" /> Notarize Another File
          </Button>
        </div>
      );
    }

    if (isHashing) {
      return (
        <div className="flex flex-col items-center justify-center h-48 space-y-2">
          <Loader className="h-8 w-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Calculating file digest...</p>
        </div>
      );
    }

    if (digest && file) {
      return (
        <div className="space-y-6">
          <div>
            <Label>File</Label>
            <p className="text-sm font-medium text-foreground truncate">{file.name}</p>
          </div>
          <div>
            <Label htmlFor="digest">SHA256 Digest</Label>
            <p id="digest" className="text-sm font-mono break-all bg-muted p-2 rounded-md text-muted-foreground">{digest}</p>
          </div>
          <div className="flex items-center justify-between rounded-lg border p-3 shadow-sm">
            <div>
                <Label htmlFor="network-switch" className="font-semibold">Broadcast Network</Label>
                <p className="text-xs text-muted-foreground">Mainnet requires a transaction fee.</p>
            </div>
            <div className="flex items-center gap-2">
                <Label htmlFor="network-switch" className="text-sm text-muted-foreground">Testnet</Label>
                <Switch id="network-switch" checked={isPremium} onCheckedChange={setIsPremium} aria-label="Toggle network" />
                <Label htmlFor="network-switch" className="text-sm text-accent font-bold">Mainnet</Label>
            </div>
          </div>
          <Button onClick={handleSubmit} disabled={isPending} className="w-full bg-accent text-accent-foreground hover:bg-accent/90">
            {isPending ? (<Loader className="mr-2 h-4 w-4 animate-spin" />) : (<Fingerprint className="mr-2 h-4 w-4" />)}
            Submit to Blockchain
          </Button>
        </div>
      );
    }

    return (
        <div
            className="flex flex-col items-center justify-center text-center p-8 border-2 border-dashed border-border rounded-lg h-48 hover:border-primary transition-colors cursor-pointer"
            onClick={() => fileInputRef.current?.click()}
            onDrop={(e) => { e.preventDefault(); handleFileChange({ target: { files: e.dataTransfer.files } } as any); }}
            onDragOver={(e) => e.preventDefault()}
        >
            <FileUp className="w-12 h-12 text-muted-foreground" />
            <p className="mt-4 text-muted-foreground">Drag & drop your file here or</p>
            <span className="mt-2 text-primary font-semibold">Select a File</span>
        </div>
    );
  };

  return (
    <Card className="w-full max-w-md shadow-2xl shadow-primary/10">
      <CardHeader>
        <CardTitle>Apreturn Notarization</CardTitle>
        <CardDescription>
          Create a timestamped, immutable proof of existence for any file.
        </CardDescription>
      </CardHeader>
      <CardContent className="min-h-[20rem] flex items-center justify-center">
        <Input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          className="hidden"
        />
        {renderContent()}
      </CardContent>
      <CardFooter className="text-xs text-muted-foreground">
        Your file is never uploaded. The SHA256 digest is calculated in your browser.
      </CardFooter>
    </Card>
  );
}
