"use server";

// A mock function to simulate blockchain interaction
async function broadcastTransaction(
  digest: string,
  network: "testnet" | "mainnet"
): Promise<{ txId: string; timestamp: Date }> {
  console.log(`Broadcasting digest ${digest.substring(0, 10)}... to ${network}`);

  // Simulate network delay and potential failures
  await new Promise((resolve) =>
    setTimeout(resolve, 1500 + Math.random() * 2000)
  );

  if (network === 'mainnet' && Math.random() < 0.1) { // 10% chance of failure on mainnet for demo purposes
    throw new Error("Failed to broadcast transaction. The network might be congested. Please try again.");
  }

  // Generate a fake transaction ID (64 hex characters)
  const txId = Array.from(
    { length: 64 },
    () => "0123456789abcdef"[Math.floor(Math.random() * 16)]
  ).join("");
  const timestamp = new Date();

  return { txId, timestamp };
}

export async function submitDigest(
  digest: string,
  network: "testnet" | "mainnet"
): Promise<{ txId?: string; timestamp?: Date; error?: string }> {
  try {
    // Basic validation for the digest format on the server
    if (!/^[a-f0-9]{64}$/.test(digest)) {
      return {
        error: "Invalid SHA-256 digest format. Please select a valid file.",
      };
    }

    const { txId, timestamp } = await broadcastTransaction(digest, network);

    return { txId, timestamp };
  } catch (error) {
    console.error("Blockchain submission error:", error);
    return {
      error:
        error instanceof Error
          ? error.message
          : "An unknown server error occurred.",
    };
  }
}
