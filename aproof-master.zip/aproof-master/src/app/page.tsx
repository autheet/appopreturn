import { ApreturnClient } from '@/components/aproof-client';
import { Github } from 'lucide-react';

export default function Home() {
  // An icon to represent blockchain, like a stylized block or chain link.
  const BlockchainIcon = () => (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="h-6 w-6 text-primary"
    >
      <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"></path>
    </svg>
  );

  return (
    <div className="flex flex-col min-h-dvh bg-background">
      <header className="px-4 lg:px-6 h-14 flex items-center shadow-sm">
        <a className="flex items-center justify-center gap-2" href="#">
          <BlockchainIcon />
          <span className="font-semibold text-lg">Apreturn</span>
        </a>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <a
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            href="https://github.com/firebase/studio-extra-requests/tree/main/aproof"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="View source code on GitHub"
          >
            <Github className="h-5 w-5" />
          </a>
        </nav>
      </header>
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6">
        <ApreturnClient />
      </main>
    </div>
  );
}
