# **App Name**: Aproof

## Core Features:

- File Selection: Allow users to select a file from their device or share a file to the app with an intent.
- Digest Creation: Generate the SHA256 digest of the selected file on the user's device.
- Blockchain Submission: Submit the digest to the Bitcoin testnet (free version) or mainnet (premium) using OP_RETURN via a python cloud function that is called from the app.
- Transaction ID Display: Provide users with a transaction ID or link to view the OP_RETURN transaction on a block explorer.
- Timestamp Display: Show the date and time when the digest was recorded on the blockchain based on the transaction timestamp.
- Premium Version: Determine whether to broadcast to testnet, or mainnet, as an unlockable feature

## Style Guidelines:

- Primary color: Sky blue (#87CEEB) for a trustworthy and secure feel.
- Background color: Very light blue (#F0F8FF), nearly white to ensure easy readability and a clean interface.
- Accent color: Teal (#008080), a contrasting color to draw attention to key actions and information.
- Body and headline font: 'Inter', a grotesque-style sans-serif, providing a modern, objective, and neutral aesthetic.
- Use minimalistic icons that represent security, file sharing, and blockchain technology.
- Maintain a clean and intuitive layout, prioritizing ease of use and clear presentation of information.
- Use subtle animations to provide feedback during file processing and transaction submission.